<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>
<body>
  <!-- Sections for different pets -->
<section id="grooming">
    <h2>Grooming</h2>
    <p>Content about grooming...</p>
</section>
<section id="environment">
    <h2>Proper Environment/Caging</h2>
    <p>Content about proper environment...</p>
</section>
<section id="nutrition">
    <h2>Nutrition</h2>
    <p>Content about nutrition...</p>
</section>
<section id="teaching">
    <h2>Dos and Don’ts (Teaching)</h2>
    <p>Content about teaching...</p>
</section>
<section id="products">
    <h2>Recommended Products</h2>
    <p>Content about recommended products...</p>
</section>

</body>
</html>